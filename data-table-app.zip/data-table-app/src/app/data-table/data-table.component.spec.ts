import { TestBed, async } from '@angular/core/testing';
import { DataTableComponent } from './data-table.component';
import { DataTableService } from '../services/data-table.service';
import { of } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DataTablePaginationComponent } from '../data-table-pagination/data-table-pagination.component';
import { Column } from '../model/column.model';
import { Data } from '../model/data.model';
import { Request } from '../model/row-data-request.model';
const data: Data[] = [{
    name: 'Nell D. Michael',
    phone: '602-1033',
    email: 'hendrerit.id.ante@placeratvelit.ca',
    company: 'Praesent Eu LLP',
    date_entry: '2017-07-30 23:27:39',
    org_num: '907369 2973',
    address_1: 'P.O. Box 916, 8584 Vestibulum St.',
    city: 'Vitry-sur-Seine',
    zip: '2353',
    geo: '60.77971, 7.98874',
    pan: '4532992507580',
    pin: '7086',
    id: 1,
    status: 'read',
    fee: '$60.99',
    guid: '48653E36-987F-48EC-7382-7F009FF34628',
    date_exit: '2018-11-14 12:37:54',
    date_first: '2018-05-20 01:07:05',
    date_recent: '2019-04-06 23:28:25',
    url: 'https://capco.com/'
}];
const dataTableService = {
    getData: () => {
    },
    setData: () => { },
    calculateWidth: () => { },
    getTotalWidth: () => { },
    getColumns: () => { },
    postRowData: () => { }
};

describe('DataTableComponent', () => {
    let fixture;
    let component: DataTableComponent;
    let service: DataTableService;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                DataTableComponent,
                DataTablePaginationComponent
            ],
            providers: [{ provide: DataTableService, useValue: dataTableService }],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DataTableComponent);
        component = fixture.debugElement.componentInstance;
        service = fixture.debugElement.injector.get(DataTableService);
    });

    it('should create the app', () => {
        expect(component).toBeTruthy();
    });

    it('test ngOnInit', () => {
        const getDataSpy = spyOn(service, 'getData').and.returnValue(of(data));
        const setDataSpy = spyOn(service, 'setData');
        const calculateWidthSpy = spyOn(service, 'calculateWidth');
        const getTotalWidthSpy = spyOn(service, 'getTotalWidth');
        component.ngOnInit();
        expect(setDataSpy).toHaveBeenCalled();
        expect(component.data).toEqual(data);
        expect(calculateWidthSpy).toHaveBeenCalled();
        expect(getTotalWidthSpy).toHaveBeenCalled();
    });

    it('test pageChange', () => {
        const getDataSpy = spyOn(service, 'getData').and.returnValue(of(data));
        const pagination = {
            pageSize: 10,
            pages: 5,
            pageIndex: 1
        };
        component.pageChange(pagination);
        expect(component.data.length).toBe(1);
    });

    it('test submit', () => {
        const item = data[0];
        const params: Request = {
            id: item.id,
            status: item.status
        };
        const postRowDataSpy = spyOn(service, 'postRowData').and.returnValue(of({status: 'done'}));
        component.submit(item);
        expect(postRowDataSpy).toHaveBeenCalledWith(params);
    });
});

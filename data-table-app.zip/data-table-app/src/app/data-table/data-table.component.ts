import { Component, OnInit } from '@angular/core';
import { DataTableService } from '../services/data-table.service';
import { Data } from '../model/data.model';
import { Column } from '../model/column.model';
import { Request } from '../model/row-data-request.model';

@Component({
    selector: 'app-data-table',
    templateUrl: './data-table.component.html',
    styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {
    columns = [];
    data = [];
    totalWidth = 0;
    loading = false;
    constructor(private dataTableService: DataTableService) {

    }
    ngOnInit() {
        this.loading = true;
        this.dataTableService.getData().subscribe((data: Data[]) => {
            this.loading = false;
            this.dataTableService.setData(data);
            this.data = data;
        }, () => {
            // Error Handler: Real case we may use toaster or snackbar to update the user abou the error
            this.loading = false;
            console.log('Please try after sometime');
        });
        this.columns = this.dataTableService.calculateWidth(this.dataTableService.getColumns());
        this.totalWidth = this.dataTableService.getTotalWidth(this.columns);
    }

    pageChange(event: any) {
        const start = (event.pageIndex - 1) * event.pageSize;
        this.dataTableService.getData().subscribe((data: Data[]) => {
            this.data = data.splice(start, event.pageSize);
        });
    }

    submit(item: Data) {
        const params: Request = {
            id: item.id,
            status: item.status
        };
        this.dataTableService.postRowData(params).subscribe(() => {
        }, (error) => {
            console.log('Method not implemented');
        });
    }
}

import { TestBed, async } from '@angular/core/testing';
import { DataTablePaginationComponent } from './data-table-pagination.component';
import { DataTableService } from '../services/data-table.service';
import { of } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';

const data = [{
    name: 'Nell D. Michael',
    phone: '602-1033',
    email: 'hendrerit.id.ante@placeratvelit.ca',
    company: 'Praesent Eu LLP',
    date_entry: '2017-07-30 23:27:39',
    org_num: '907369 2973',
    address_1: 'P.O. Box 916, 8584 Vestibulum St.',
    city: 'Vitry-sur-Seine',
    zip: '2353',
    geo: '60.77971, 7.98874',
    pan: '4532992507580',
    pin: '7086',
    id: 1,
    status: 'read',
    fee: '$60.99',
    guid: '48653E36-987F-48EC-7382-7F009FF34628',
    date_exit: '2018-11-14 12:37:54',
    date_first: '2018-05-20 01:07:05',
    date_recent: '2019-04-06 23:28:25',
    url: 'https://capco.com/'
}];
const dataTableService = {
    getData: () => {
    },
    setData: () => { },
    calculateWidth: () => { },
    getTotalWidth: () => { },
    getColumns: () => { }
};

describe('DataTablePaginationComponent', () => {
    let fixture;
    let component: DataTablePaginationComponent;
    let service: DataTableService;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                DataTablePaginationComponent,
                DataTablePaginationComponent
            ],
            providers: [{ provide: DataTableService, useValue: dataTableService }],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DataTablePaginationComponent);
        component = fixture.debugElement.componentInstance;
        service = fixture.debugElement.injector.get(DataTableService);
    });

    it('should create the app', () => {
        expect(component).toBeTruthy();
    });

    it('test ngOnInit', () => {
        const pageSizeChangeSpy = spyOn(component, 'pageSizeChange');
        component.ngOnInit();
        expect(pageSizeChangeSpy).toHaveBeenCalled();
    });

    it('test pageSizeChange', () => {
        const getDataSpy = spyOn(service, 'getData').and.returnValue(of(data));
        const getPagesSpy = spyOn(component, 'getPages').and.returnValue(1);
        const pageChangeEmitSpy = spyOn(component.pageChange, 'emit');
        component.pageSize = 10;
        component.pageIndex = 1;
        component.pageSizeChange();
        expect(getPagesSpy).toHaveBeenCalled();
        expect(component.totalRecords).toBe(1);
        expect(component.start).toBe(1);
        expect(component.end).toBe(10);
        expect(component.totalRecords).toBe(1);
        expect(pageChangeEmitSpy).toHaveBeenCalledWith({
            pageSize: 10,
            pages: 1,
            pageIndex: 1
        });
    });

    it('test getPages', () => {
        component.pageSize = 10;
        expect(component.getPages(data)).toBe(1);
    });

    it('test updatePage: FIRST', () => {
        const pageSizeChangeSpy = spyOn(component, 'pageSizeChange');
        component.updatePage('FIRST');
        expect(component.pageIndex).toBe(1);
        expect(pageSizeChangeSpy).toHaveBeenCalled();
    });
    it('test updatePage: PREV', () => {
        const pageSizeChangeSpy = spyOn(component, 'pageSizeChange');
        component.pageIndex = 2;
        component.updatePage('PREV');
        expect(component.pageIndex).toBe(1);
        expect(pageSizeChangeSpy).toHaveBeenCalled();
    });
    it('test updatePage: NEXT', () => {
        const pageSizeChangeSpy = spyOn(component, 'pageSizeChange');
        component.pageIndex = 2;
        component.updatePage('NEXT');

        expect(component.pageIndex).toBe(3);
        expect(pageSizeChangeSpy).toHaveBeenCalled();
    });
    it('test updatePage: LAST', () => {
        const pageSizeChangeSpy = spyOn(component, 'pageSizeChange');
        component.pages = 2;
        component.updatePage('LAST');
        expect(component.pageIndex).toBe(2);
        expect(pageSizeChangeSpy).toHaveBeenCalled();
    });
});

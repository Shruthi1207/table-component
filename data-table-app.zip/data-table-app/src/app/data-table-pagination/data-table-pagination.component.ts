import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataTableService } from '../services/data-table.service';
import { Data } from '../model/data.model';


@Component({
    selector: 'app-data-table-pagination',
    templateUrl: './data-table-pagination.component.html',
    styleUrls: ['./data-table-pagination.component.scss']
})
export class DataTablePaginationComponent implements OnInit {
    @Output() pageChange = new EventEmitter();
    pageSizes = [5, 10, 15, 20];
    pageSize = 10;
    pages = 0;
    pageIndex = 1;
    totalRecords = 0;
    start = 0;
    end = 0;
    constructor(private dataTableService: DataTableService) { }
    ngOnInit() {
        this.pageSizeChange();
    }

    pageSizeChange() {
        this.dataTableService.getData().subscribe((data: Data[]) => {
            this.pages = this.getPages(data);
            this.totalRecords = data.length;
            this.start = ((this.pageIndex - 1) * this.pageSize) + 1;
            this.end = this.pageIndex * this.pageSize;
            this.pageChange.emit({
                pageSize: this.pageSize,
                pages: this.pages,
                pageIndex: this.pageIndex
            });
        });
    }

    getPages(data: Data[]) {
        return Math.ceil(data.length / this.pageSize);
    }

    updatePage(value: string) {
        switch (value) {
            case 'FIRST':
                this.pageIndex = 1; break;
            case 'PREV':
                this.pageIndex = this.pageIndex - 1; break;
            case 'NEXT':
                this.pageIndex = this.pageIndex + 1; break;
            case 'LAST':
                this.pageIndex = this.pages; break;
        }
        this.pageSizeChange();
    }
}

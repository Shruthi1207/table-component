export interface Request {
    id: number;
    status: string;
}

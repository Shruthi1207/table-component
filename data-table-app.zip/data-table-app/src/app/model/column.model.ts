export interface Column {
    id: string;
    label: string;
    width?: number;
}

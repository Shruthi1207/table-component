import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { Column } from '../model/column.model';
import { Data } from '../model/data.model';
import { Request } from '../model/row-data-request.model';

@Injectable()
export class DataTableService {
    data: Data[];
    totalWidth = 0;
    columnWidth = 150;
    constructor(private http: HttpClient) {

    }
    getData() {
        if (this.data) {
            return of([...this.data]);
        }
        return this.http.get('/assets/data/data.json');
    }
    postRowData(params: Request) {
        return this.http.post('/api/submit', params);
    }
    setData(data: Data[]) {
        this.data = data;
    }

    getColumns(): Column[] {
        return [{
            id: 'name',
            label: 'Name'
        }, {
            id: 'phone',
            label: 'Phone'
        }, {
            id: 'email',
            label: 'Email'
        }, {
            id: 'company',
            label: 'Company',
            width: 100
        },
        {
            id: 'date_entry',
            label: 'Date'
        }, {
            id: 'org_num',
            label: 'Org Num'
        }, {
            id: 'address_1',
            label: 'Address'
        }, {
            id: 'city',
            label: 'City'
        }, {
            id: 'zip',
            label: 'Zip'
        },
        {
            id: 'geo',
            label: 'Geo'
        },
        {
            id: 'actions',
            label: 'Actions'
        }];
    }

    calculateWidth(columns: Column[]) {
        return columns.map((column) => {
            if (!column.width) {
                column.width = this.columnWidth;
            }
            return column;
        });
    }

    getTotalWidth(columns: Column[]) {
        return columns.reduce((accumulator: number, column: Column) => {
            return accumulator + column.width;
        }, 0);
    }
}

import { TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import {
    HttpClientTestingModule,
    HttpTestingController
} from '@angular/common/http/testing';
import { of } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DataTableService } from './data-table.service';
import { Column } from '../model/column.model';
import { Data } from '../model/data.model';
import { Request } from '../model/row-data-request.model';

const data = [{
    name: 'Nell D. Michael',
    phone: '602-1033',
    email: 'hendrerit.id.ante@placeratvelit.ca',
    company: 'Praesent Eu LLP',
    date_entry: '2017-07-30 23:27:39',
    org_num: '907369 2973',
    address_1: 'P.O. Box 916, 8584 Vestibulum St.',
    city: 'Vitry-sur-Seine',
    zip: '2353',
    geo: '60.77971, 7.98874',
    pan: '4532992507580',
    pin: '7086',
    id: 1,
    status: 'read',
    fee: '$60.99',
    guid: '48653E36-987F-48EC-7382-7F009FF34628',
    date_exit: '2018-11-14 12:37:54',
    date_first: '2018-05-20 01:07:05',
    date_recent: '2019-04-06 23:28:25',
    url: 'https://capco.com/'
}];

describe('DataTableService', () => {
    let service: DataTableService;
    let httpMock: HttpTestingController;
    beforeEach(async(() => {
        const spy = jasmine.createSpyObj('HttpClient', ['get', 'post']);
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [DataTableService],
            schemas: [NO_ERRORS_SCHEMA]
        });
    }));

    beforeEach(() => {
        service = TestBed.get(DataTableService);
        httpMock = TestBed.get(HttpTestingController);
    });

    it('should create the service', () => {
        expect(service).toBeTruthy();
    });

    it('should setData', () => {
        service.setData(data);
        expect(service.data).toEqual(data);
    });

    it('should getColumns', () => {
        expect(service.getColumns().length).toBeGreaterThan(0);
    });

    it('should calculateWidth', () => {
        const columns: Column[] = [{
            id: 'name',
            label: 'Name'
        }];

        expect(service.calculateWidth(columns)).toEqual([{
            id: 'name',
            label: 'Name',
            width: 150
        }]);
    });

    it('should getTotalWidth', () => {
        const columns: Column[] = [{
            id: 'name',
            label: 'Name',
            width: 150
        }, {
            id: 'email',
            label: 'Email',
            width: 100
        }];

        expect(service.getTotalWidth(columns)).toBe(250);
    });

    it('should getData', () => {
        const url = '/assets/data/data.json';
        service.getData().subscribe((response: Data[]) => {
            expect(response.length).toBe(1);
        });
        const request = httpMock.expectOne(url);
        request.flush(data);
        httpMock.verify();
    });

    it('should postRowData', () => {
        const url = '/api/submit';
        const params: Request = {
            id: 1,
            status: 'read'
        };
        service.postRowData(params).subscribe((response: any) => {
            expect(response.status).toBe('done');
        });
        const request = httpMock.expectOne(url);
        request.flush({status: 'done'});
        httpMock.verify();
    });


});

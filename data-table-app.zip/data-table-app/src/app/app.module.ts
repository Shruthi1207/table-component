import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { DataTableComponent } from './data-table/data-table.component';
import { DataTableService } from './services/data-table.service';
import { DataTablePaginationComponent } from './data-table-pagination/data-table-pagination.component';

@NgModule({
  declarations: [
    AppComponent,
    DataTableComponent,
    DataTablePaginationComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [DataTableService],
  bootstrap: [AppComponent]
})
export class AppModule { }
